
$(document).ready(function() {
    $(".lightgallery").lightGallery({
      hideBarsDelay: 1000,
      download: false,
      controls: false,
      counter: false,
      enableDrag: false,
      escKey: true,
      width: '800px',
      height: '570px',
    }); 
  });