document.write(
  '<div class="sidebar-header">\
  <img class="sidebar-image" src="./images/profile.jpeg">\
  <h1>Augustine S Aykara</h1>\
</div>\
<div class="social-icons">\
  <a href="https://twitter.com/AugustineAykara" title="twitter" target="_blank"><i class="inverted twitter icon"></i></a>\
  <a href="https://github.com/AugustineAykara" title="github" target="_blank"><i class="inverted github icon"></i></a>\
  <a href="https://in.linkedin.com/in/augustineaykara" title="linkedIn" target="_blank"><i class="inverted linkedin icon"></i></a>\
  <a href="mailto: augustineaykara@gmail.com" title="mail"><i class="inverted envelope icon"></i></a>\
  <a href="https://www.instagram.com/augustineaykara/" title="instagram" target="_blank"><i class="inverted instagram icon"></i></a>\
</div>\
<nav>\
  <a class="item" href="index.html"><i class="home icon"></i>HOME</a>\
  <a class="item" href="skills.html"><i class="star icon"></i>SKILLS</a>\
  <a class="item" href="websiteProjects.html"><i class="file alternate outline icon"></i>PROJECTS</a>\
  <a class="item" href="contact.html"><i class="phone icon"></i>CONTACT</a>\
</nav>\
</div>'
);
