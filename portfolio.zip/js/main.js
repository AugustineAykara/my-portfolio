$('#toggle').click(function(){
  $('.ui.sidebar').sidebar('toggle');
});
